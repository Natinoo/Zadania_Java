#!/bin/bash
echo "Wybierz co zagrasz: "
echo "1- Kamień"
echo "2- Papier"
echo "3- Nożyce"
read -r wybor

losuj_liczbe() {
    echo $(( ( RANDOM % 3 ) + 1 ))
}
wybor_komputera=$(losuj_liczbe)

if [[ $wybor =~ ^[1-3]$ ]]; then
    if [[ $wybor =~ [^a-zA-Z] ]]; then
        wybor_gracza=$wybor
    else
        echo "Ciąg zawiera niedozwolone znaki."
        exit 1
    fi
else
    echo "Niedozwolny wybór, wybierz od 1 do 3"
    exit 1
fi

if [ $wybor == $wybor_komputera ]; then
    echo "Gracz wybrał $wybor"
    echo "Komputer wybrał $wybor_komputera"
    echo "Remis"
elif ([ $wybor == 1 ] && [ $wybor_komputera == 3 ]) || 
     ([ $wybor == 2 ] && [ $wybor_komputera == 1 ]) || 
     ([ $wybor == 3 ] && [ $wybor_komputera == 2 ]); then
     echo "Gracz wybrał $wybor"
     echo "Komputer wybrał $wybor_komputera"
     echo "Gracz Wygrał!"
else
     echo "Gracz wybrał $wybor"
     echo "Komputer wybrał $wybor_komputera"
     echo "Komputer Wygrał!"
fi
