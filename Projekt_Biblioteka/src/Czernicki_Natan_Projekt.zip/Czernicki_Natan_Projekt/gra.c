#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Funkcja do generowania losowego wyboru komputera
int losowy_wybor() {
    srand(time(NULL));
    return rand() % 3 + 1; // Zwraca 1, 2 lub 3 (kamień, papier lub nożyce)
}

// Funkcja do określenia wyniku gry
void sprawdz_wynik(int wybor_gracza, int wybor_komputera) {
    if (wybor_gracza == wybor_komputera) {
        printf("Remis!\n");
    } else if ((wybor_gracza == 1 && wybor_komputera == 3) || 
               (wybor_gracza == 2 && wybor_komputera == 1) || 
               (wybor_gracza == 3 && wybor_komputera == 2)) {
        printf("Wygrałeś!\n");
    } else {
        printf("Komputer wygrał!\n");
    }
}

int main() {
    char buf[100];
    int wybor_gracza, wybor_komputera;

    printf("1. Kamień\n");
    printf("2. Papier\n");
    printf("3. Nożyce\n");
    printf("Wybierz przedmiot: ");
    if (fgets(buf, sizeof(buf), stdin) != NULL) {
        // Sprawdzenie, czy całe wejście to liczba
        if (sscanf(buf, "%d", &wybor_gracza) != 1 || buf[1] != '\n') {
            printf("Niepoprawny wybór!\n");
            return 1;
        }

        // Walidacja wyboru gracza
        if (wybor_gracza < 1 || wybor_gracza > 3) {
            printf("Niepoprawny wybór!\n");
            return 1;
        }

        wybor_komputera = losowy_wybor();
        printf("Wybór komputera: %d\n", wybor_komputera);
        sprawdz_wynik(wybor_gracza, wybor_komputera);
    } else {
        printf("Błąd odczytu danych!\n");
        return 1;
    }
    return 0;
}
